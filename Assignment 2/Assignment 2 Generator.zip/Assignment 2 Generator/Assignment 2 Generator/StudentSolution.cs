﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2_Generator
{
    class StudentSolution
    {
        public int studentNumber;
        public string BadCode;
        public string step1;
        public string step2;
        public string step3;
        public string step4;

        public StudentSolution(int sn, string badCode)
        {
            studentNumber = sn;
            BadCode = badCode;
        }
    }
}
