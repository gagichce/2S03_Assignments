package assignment3;

public class NotSquareMatrixException extends Exception{

    private static final long serialVersionUID = 1L;

    public NotSquareMatrixException () { }
    public NotSquareMatrixException (String message) { super (message); }
    public NotSquareMatrixException (Throwable cause) { super (cause); }

    public NotSquareMatrixException (String message, Throwable cause) {
        super (message, cause);
    }
}
