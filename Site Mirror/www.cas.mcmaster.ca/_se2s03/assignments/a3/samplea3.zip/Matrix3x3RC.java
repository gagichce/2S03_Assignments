package assignment3;

public class Matrix3x3RC {
    
    private MatrixRC Matrix = new MatrixRC();
    private InvalidArrayLengthException Error;
    
    public Matrix3x3RC(long[] array) throws InvalidArrayLengthException {
        if(array.length == 9) {    
            Matrix.row1.column1 = array[0];
            Matrix.row1.column2 = array[1];
            Matrix.row1.column3 = array[2];
            Matrix.row2.column1 = array[3];
            Matrix.row2.column2 = array[4];
            Matrix.row2.column3 = array[5];
            Matrix.row3.column1 = array[6];
            Matrix.row3.column2 = array[7];
            Matrix.row3.column3 = array[8];
        } else {
            throw new InvalidArrayLengthException(Error);
        }
    }

    public long determinant() {
        
        return((Matrix.row1.column1 * (Matrix.row2.column2 * Matrix.row3.column3 - Matrix.row2.column3 * Matrix.row3.column2)) 
                - (Matrix.row1.column2 * (Matrix.row2.column1 * Matrix.row3.column3 - Matrix.row2.column3 * Matrix.row3.column1))
                + (Matrix.row1.column3 * (Matrix.row2.column1 * Matrix.row3.column2 - Matrix.row2.column2 * Matrix.row3.column1)));
    }
}

// private to Marix3x3RC
class MatrixRC {
    Row row1 = new Row();
    Row row2 = new Row();
    Row row3 = new Row();
}    

class Row {
    long column1;
    long column2;
    long column3;
}
