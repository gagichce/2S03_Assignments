package assignment3;

public class MatrixArrayRC { //rows of columns
    
    private long[][] rows;
    private long[] columns;
    private int n = 0;
    private int n2 = 0;
    private NotSquareMatrixException Error;
    private InvalidArrayLengthException Error2;

    public MatrixArrayRC(long[] array) throws InvalidArrayLengthException {
        n2 = array.length;
        n = (int)Math.sqrt(n2);
        
        if(n2 == 9) {
            rows = new long[n][n];
            columns = new long[n];
            
            for(int i = 0; i < n; i++) {      //row index, i
                for(int j = 0; j < n; j++) {   //column index, j 
                    columns[j] = array[n * i + j];
                }
                System.arraycopy(columns, 0, rows[i], 0, n);
            }
        } else {
            throw new InvalidArrayLengthException(Error2);
        }
    }    
    
    public MatrixArrayRC(long[] array, int general) throws NotSquareMatrixException {
        n2 = array.length;
        n = (int)Math.sqrt(n2);
        
        if((n2 == Math.pow((double)n, 2)) && (general == 1)) {
            rows = new long[n][n];
            columns = new long[n];
            
            for(int i = 0; i < n; i++) {      //row index, i
                for(int j = 0; j < n; j++) {   //column index, j 
                    columns[j] = array[n * i + j];
                }
                System.arraycopy(columns, 0, rows[i], 0, n);
            }
        } else {
            throw new NotSquareMatrixException(Error);
        }
    }    
        
    public long determinant() throws NotSquareMatrixException {
        long det = 0, s;        //det = 1 to allow for multiplying against it
        int n = (int)(rows.length);
        
        long [][] Matrix = new long [n][n];        //making space for nxn
        
        for(int i = 0; i < n; i++) {
            System.arraycopy(rows[i], 0, Matrix[i], 0, n);        //make copy of rows[][] into Matrix[][]
        }
        
        if(n == 1) {
            return(Matrix[0][0]);
        } else if(n == 2) {
            return((Matrix[0][0] * Matrix[1][1]) - (Matrix[0][1] * Matrix[1][0]));
        } else {
            for(int i = 0; i < n; i++) {
                long[] smallerMatrix = new long[(n - 1) * (n - 1)];
                
                for(int j = 1; j < n; j++) {
                    for(int k = 0; k < n; k++) {
                        if(k < i) {
                            smallerMatrix[((n - 1) * (j - 1)) + k] = Matrix[j][k]; //Matrix[row][column]
                        } else if(k > i) {
                            smallerMatrix[((n - 1) * (j - 1)) + (k - 1)] = Matrix[j][k];
                        }
                    }
                }
                
                s = (i%2 == 0) ? 1 : -1;
                MatrixArrayRC temporaryMatrix = new MatrixArrayRC(smallerMatrix, 1);
                det += s * Matrix[0][i] * (temporaryMatrix.determinant());
            }
            return det;
        }
    }
}
