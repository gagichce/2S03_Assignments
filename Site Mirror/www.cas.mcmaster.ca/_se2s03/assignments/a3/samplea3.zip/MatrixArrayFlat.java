package assignment3;

public class MatrixArrayFlat {

    private long[] MatrixFlat;
    private int n = 0;
    private int n2 = 0;
    private NotSquareMatrixException Error;
    private InvalidArrayLengthException Error2;
    
    public MatrixArrayFlat(long[] array) throws InvalidArrayLengthException {
        n2 = array.length;
                
        if(n2 == 9) {
            MatrixFlat = new long[n2];
            System.arraycopy(array, 0, MatrixFlat, 0, n2);
        } else {
            throw new InvalidArrayLengthException(Error2);
        }
    }    
    
    public MatrixArrayFlat(long[] array, int general) throws NotSquareMatrixException {
        n2 = array.length;
        n = (int)Math.sqrt(n2);
        
        if((n2 == Math.pow((double)n, 2)) && (general == 1)) {
            MatrixFlat = new long[n2];
            System.arraycopy(array, 0, MatrixFlat, 0, n2);
        } else {
            throw new NotSquareMatrixException(Error);
        }
    }    


    public long determinant() throws NotSquareMatrixException {
        long det = 0, s;        //det = 1 to allow for multiplying against it
        int n = (int)(Math.sqrt(MatrixFlat.length));
        
        if(n == 1) {
            return(MatrixFlat[0]);
        } else if(n == 2) {
            return((MatrixFlat[0] * MatrixFlat[3]) - (MatrixFlat[1] * MatrixFlat[2]));
        } else {
            for(int i = 0; i < n; i++) {
                long[] smallerMatrix = new long[(n - 1) * (n - 1)];     //making space of n-1 x n-1
                
                for(int j = 1; j < n; j++) {
                    for(int k = 0; k < n; k++) {
                        if(k < i) {
                            smallerMatrix[((n - 1) * (j - 1)) + k] = MatrixFlat[(n * j) + k]; //MatrixFlat[n * row + column]
                        } else if(k > i) {
                            smallerMatrix[((n - 1) * (j - 1)) + (k - 1)] = MatrixFlat[(n * j) + k];
                        }
                    }
                }
                
                s = (i%2 == 0) ? 1 : -1;
                MatrixArrayFlat temporaryMatrix = new MatrixArrayFlat(smallerMatrix, 1);
                det += s * MatrixFlat[i] * (temporaryMatrix.determinant());
            }
            return det;
        }
    }
}
