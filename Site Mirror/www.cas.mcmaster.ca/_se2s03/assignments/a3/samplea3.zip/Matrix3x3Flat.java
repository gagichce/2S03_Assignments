package assignment3;

public class Matrix3x3Flat {
    private Flat Matrix = new Flat();
    private InvalidArrayLengthException Error;
        
    public Matrix3x3Flat(long[] array) throws InvalidArrayLengthException {
        if (array.length == 9) {
            Matrix.a11 = array[0];
            Matrix.a12 = array[1];
            Matrix.a13 = array[2];
            Matrix.a21 = array[3];
            Matrix.a22 = array[4];
            Matrix.a23 = array[5];
            Matrix.a31 = array[6];
            Matrix.a32 = array[7];
            Matrix.a33 = array[8];
        } else {
            throw new InvalidArrayLengthException(Error);
        }
    }
    
    public long determinant() {
        
        return((Matrix.a11 * (Matrix.a22 * Matrix.a33 - Matrix.a23 * Matrix.a32)) 
                - (Matrix.a12 * (Matrix.a21 * Matrix.a33 - Matrix.a23 * Matrix.a31))
                + (Matrix.a13 * (Matrix.a21 * Matrix.a32 - Matrix.a22 * Matrix.a31)));
    }
}

// private to Matrix3x3Flat
class Flat {
    long a11; long a12; long a13;
    long a21; long a22; long a23;
    long a31; long a32; long a33;
}
