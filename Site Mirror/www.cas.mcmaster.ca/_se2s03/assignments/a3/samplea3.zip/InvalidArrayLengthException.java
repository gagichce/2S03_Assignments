package assignment3;

public class InvalidArrayLengthException extends Exception{

    private static final long serialVersionUID = 1L;

    public InvalidArrayLengthException () { }
    public InvalidArrayLengthException (String message) { super (message); }
    public InvalidArrayLengthException (Throwable cause) { super (cause); }
    public InvalidArrayLengthException (String message, Throwable cause) {
        super (message, cause);
    }
}
