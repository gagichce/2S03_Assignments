package assignment3;

import static org.junit.Assert.*;

import org.junit.Test;

public class testingTest {

    Matrix3x3Flat MatrixOne;
    Matrix3x3RC MatrixTwo;
    Matrix3x3CR MatrixThree;
    MatrixArrayFlat MatrixFour;
    MatrixArrayRC MatrixFive;
    MatrixArrayCR MatrixSix;
        
    int n = 10;
    
    long[][] Matrices = {{1, 2, 3, 4, 5, 6, 7, 8, 9},
                        {5, 10, 15, 20, 25, 30, 35, 40, 45},
                        {4, 1, 5, 7, 3, 15, 4, 2, 10},
                        {3, 6, 9, 3, 6, 9, 3, 6, 9},
                        {1, 1, 1, 1, 1, 1, 1, 1, 1},
                        {1, 7, 14, 1, 5, 3, 1, 2, 9},
                        {17, 1, 12, 43, 26, 33, 28, 55, 67},
                        {18, 1, 31, 2, 65, 44, 54, 21, 73},
                        {1, 6, 14, 9, 1, 46, 1, 3, 8},
                        {31, 34, 23, 67, 45, 2, 99, 123, 146}}; 

    long[] expected = {0, 0, 0, 0, 0, -45, 16446, -36500, 78, -42734};
    
    @Test
    public void test() throws InvalidArrayLengthException, NotSquareMatrixException {

        for(int i = 0; i < n; i++) {
            MatrixOne = new Matrix3x3Flat(Matrices[i]);
            MatrixTwo = new Matrix3x3RC(Matrices[i]);
            MatrixThree = new Matrix3x3CR(Matrices[i]);
            MatrixFour = new MatrixArrayFlat(Matrices[i]);
            MatrixFive = new MatrixArrayRC(Matrices[i]);
            MatrixSix = new MatrixArrayCR(Matrices[i]);
            
            assertEquals("MatrixOne.det() must be " +expected[i], expected[i], MatrixOne.determinant());
            assertEquals("MatrixTwo.det() must be " +expected[i], expected[i], MatrixTwo.determinant());
            assertEquals("MatrixThree.det() must be " +expected[i], expected[i], MatrixThree.determinant());
            assertEquals("MatrixFour.det() must be " +expected[i], expected[i], MatrixFour.determinant());
            assertEquals("MatrixFive.det() must be " +expected[i], expected[i], MatrixFive.determinant());
            assertEquals("MatrixSix.det() must be " +expected[i], expected[i], MatrixSix.determinant());
        }
        
        for(int j = 0; j < n; j++) {
            MatrixOne = new Matrix3x3Flat(Matrices[j]);
            MatrixTwo = new Matrix3x3RC(Matrices[j]);
            MatrixThree = new Matrix3x3CR(Matrices[j]);
            MatrixFour = new MatrixArrayFlat(Matrices[j]);
            MatrixFive = new MatrixArrayRC(Matrices[j]);
            MatrixSix = new MatrixArrayCR(Matrices[j]);
            
            assertEquals("MatrixOne.det() must equal MatrixOne.det()", MatrixOne.determinant(), MatrixOne.determinant());
            assertEquals("MatrixOne.det() must equal MatrixTwo.det()", MatrixOne.determinant(), MatrixTwo.determinant());
            assertEquals("MatrixOne.det() must equal MatrixThree.det()", MatrixOne.determinant(), MatrixThree.determinant());
            assertEquals("MatrixOne.det() must equal MatrixFour.det()", MatrixOne.determinant(), MatrixFour.determinant());
            assertEquals("MatrixOne.det() must equal MatrixFive.det()", MatrixOne.determinant(), MatrixFive.determinant());
            assertEquals("MatrixOne.det() must equal MatrixSix.det()", MatrixOne.determinant(), MatrixSix.determinant());
            
            assertEquals("MatrixTwo.det() must equal MatrixOne.det()", MatrixTwo.determinant(), MatrixOne.determinant());
            assertEquals("MatrixTwo.det() must equal MatrixTwo.det()", MatrixTwo.determinant(), MatrixTwo.determinant());
            assertEquals("MatrixTwo.det() must equal MatrixThree.det()", MatrixTwo.determinant(), MatrixThree.determinant());
            assertEquals("MatrixTwo.det() must equal MatrixFour.det()", MatrixTwo.determinant(), MatrixFour.determinant());
            assertEquals("MatrixTwo.det() must equal MatrixFive.det()", MatrixTwo.determinant(), MatrixFive.determinant());
            assertEquals("MatrixTwo.det() must equal MatrixSix.det()", MatrixTwo.determinant(), MatrixSix.determinant());
            
            assertEquals("MatrixThree.det() must equal MatrixOne.det()", MatrixThree.determinant(), MatrixOne.determinant());
            assertEquals("MatrixThree.det() must equal MatrixTwo.det()", MatrixThree.determinant(), MatrixTwo.determinant());
            assertEquals("MatrixThree.det() must equal MatrixThree.det()", MatrixThree.determinant(), MatrixThree.determinant());
            assertEquals("MatrixThree.det() must equal MatrixFour.det()", MatrixThree.determinant(), MatrixFour.determinant());
            assertEquals("MatrixThree.det() must equal MatrixFive.det()", MatrixThree.determinant(), MatrixFive.determinant());
            assertEquals("MatrixThree.det() must equal MatrixSix.det()", MatrixThree.determinant(), MatrixSix.determinant());
            
            assertEquals("MatrixFour.det() must equal MatrixOne.det()", MatrixFour.determinant(), MatrixOne.determinant());
            assertEquals("MatrixFour.det() must equal MatrixTwo.det()", MatrixFour.determinant(), MatrixTwo.determinant());
            assertEquals("MatrixFour.det() must equal MatrixThree.det()", MatrixFour.determinant(), MatrixThree.determinant());
            assertEquals("MatrixFour.det() must equal MatrixFour.det()", MatrixFour.determinant(), MatrixFour.determinant());
            assertEquals("MatrixFour.det() must equal MatrixFive.det()", MatrixFour.determinant(), MatrixFive.determinant());
            assertEquals("MatrixFour.det() must equal MatrixSix.det()", MatrixFour.determinant(), MatrixSix.determinant());
            
            assertEquals("MatrixFive.det() must equal MatrixOne.det()", MatrixFive.determinant(), MatrixOne.determinant());
            assertEquals("MatrixFive.det() must equal MatrixTwo.det()", MatrixFive.determinant(), MatrixTwo.determinant());
            assertEquals("MatrixFive.det() must equal MatrixThree.det()", MatrixFive.determinant(), MatrixThree.determinant());
            assertEquals("MatrixFive.det() must equal MatrixFour.det()", MatrixFive.determinant(), MatrixFour.determinant());
            assertEquals("MatrixFive.det() must equal MatrixFive.det()", MatrixFive.determinant(), MatrixFive.determinant());
            assertEquals("MatrixFive.det() must equal MatrixSix.det()", MatrixFive.determinant(), MatrixSix.determinant());
            
            assertEquals("MatrixSix.det() must equal MatrixOne.det()", MatrixSix.determinant(), MatrixOne.determinant());
            assertEquals("MatrixSix.det() must equal MatrixTwo.det()", MatrixSix.determinant(), MatrixTwo.determinant());
            assertEquals("MatrixSix.det() must equal MatrixThree.det()", MatrixSix.determinant(), MatrixThree.determinant());
            assertEquals("MatrixSix.det() must equal MatrixFour.det()", MatrixSix.determinant(), MatrixFour.determinant());
            assertEquals("MatrixSix.det() must equal MatrixFive.det()", MatrixSix.determinant(), MatrixFive.determinant());
            assertEquals("MatrixSix.det() must equal MatrixSix.det()", MatrixSix.determinant(), MatrixSix.determinant());
        }
    }
}
