package assignment3;

public class Matrix3x3CR {
    private MatrixCR Matrix = new MatrixCR();
    private InvalidArrayLengthException Error;
    
    public Matrix3x3CR(long[] array) throws InvalidArrayLengthException {
        if(array.length == 9) {    
            Matrix.column1.row1 = array[0];
            Matrix.column2.row1 = array[1];
            Matrix.column3.row1 = array[2];
            Matrix.column1.row2 = array[3];
            Matrix.column2.row2 = array[4];
            Matrix.column3.row2 = array[5];
            Matrix.column1.row3 = array[6];
            Matrix.column2.row3 = array[7];
            Matrix.column3.row3 = array[8];
        } else {
            throw new InvalidArrayLengthException(Error);
        }
    }
    public long determinant() {
        
        return((Matrix.column1.row1 * ((Matrix.column2.row2 * Matrix.column3.row3) - (Matrix.column3.row2 * Matrix.column2.row3))) 
                - (Matrix.column2.row1 * ((Matrix.column1.row2 * Matrix.column3.row3) - (Matrix.column3.row2 * Matrix.column1.row3)))
                + (Matrix.column3.row1 * ((Matrix.column1.row2 * Matrix.column2.row3) - (Matrix.column2.row2 * Matrix.column1.row3))));
    }
}

// these are private to Matrix3x3CR
class MatrixCR {
    Column column1 = new Column();
    Column column2 = new Column();
    Column column3 = new Column();
}    

class Column {
    long row1;
    long row2;
    long row3;
}
